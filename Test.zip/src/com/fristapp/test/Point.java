package com.fristapp.test;

public class Point {
	public double x;
	public double y;
	public Point(double a, double b){
		x=a;y=b;
	}

}
