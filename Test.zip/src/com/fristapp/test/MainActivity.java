package com.fristapp.test;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener{

	TextView lengthView;
	TextView momentView;
	TextView qView;
	TextView pView;
	P p = new P(0,0);
	Q q = new Q(0,0,0);
	M m = new M(0,0);
	double totalmoment,totalq,totalp;
	double length;
	ImageView imaga;
	AlertDialog.Builder dialog;
	Dialog myDialog;
	EditText aEditText,bEditText,amountEditText,lengthEditText;
	Button temp;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        totalmoment=0;totalp=0;totalq=0;
        length=0;
        lengthView = (TextView) findViewById(R.id.lengthView);
        momentView = (TextView) findViewById(R.id.momentView);
        qView = (TextView) findViewById(R.id.qView);
        pView = (TextView) findViewById(R.id.pView);
       
        
        
        findViewById(R.id.addQ).setOnClickListener((OnClickListener) this);
        findViewById(R.id.addMoment).setOnClickListener((OnClickListener) this);
        findViewById(R.id.addP).setOnClickListener((OnClickListener) this);
        findViewById(R.id.calc).setOnClickListener((OnClickListener) this);
        totalmoment=0;totalp=0;totalq=0;
        length=0;
       
    	myDialog = new Dialog(MainActivity.this);
        myDialog.setContentView(R.layout.length_dialog);
        myDialog.setTitle("������� �����");
        aEditText=(EditText)myDialog.findViewById(R.id.length_a);
                  
        temp=(Button)myDialog.findViewById(R.id.length_ok);
        temp.setOnClickListener(new OnClickListener() {
             @Override
              public void onClick(View v) {
                    
                    length = Double.parseDouble(aEditText.getText().toString());
                    lengthView.setText("Length = "+length);
                    qView.setText("Q = "+totalq);  
                    momentView.setText("M = "+totalmoment); 
                    pView.setText("P = "+totalp);  
                    myDialog.cancel();
              }
        });
        myDialog.show();      

      }

    public void onClick(View v) {
    	
    	Intent intent = new Intent(this, com.fristapp.test.ResultActivity.class);
    	
    	
        switch (v.getId()) {
        
       
        case R.id.addMoment:
        	myDialog = new Dialog(MainActivity.this);
            myDialog.setContentView(R.layout.m_dialog);
            myDialog.setTitle("������");
            aEditText=(EditText)myDialog.findViewById(R.id.m_a);    
            amountEditText=(EditText)myDialog.findViewById(R.id.m_amount);             
            temp=(Button)myDialog.findViewById(R.id.m_ok);
            temp.setOnClickListener(new OnClickListener() {
                 @Override
                  public void onClick(View v) {
                        m.a=Double.parseDouble(aEditText.getText().toString());
                        m.amount=Double.parseDouble(amountEditText.getText().toString());
                        totalmoment=Double.parseDouble(amountEditText.getText().toString());
                        momentView.setText("M = "+totalmoment); 
                        myDialog.cancel();
                  }
            });
            myDialog.show();
        	Toast.makeText(this, "AddMoment", Toast.LENGTH_SHORT).show();        	        	        	
        	break;        
        case R.id.addQ:
        	Toast.makeText(this, "AddQ", Toast.LENGTH_SHORT).show();        	
        	myDialog = new Dialog(MainActivity.this);
            myDialog.setContentView(R.layout.q_dialog);
            myDialog.setTitle("�������������� ��������");
            aEditText=(EditText)myDialog.findViewById(R.id.q_a);
            bEditText=(EditText)myDialog.findViewById(R.id.q_b);
            amountEditText=(EditText)myDialog.findViewById(R.id.q_amount);             
            temp=(Button)myDialog.findViewById(R.id.q_ok);
            temp.setOnClickListener(new OnClickListener() {
                 @Override
                  public void onClick(View v) {
                	 double a=Double.parseDouble(aEditText.getText().toString());
                	 double b=Double.parseDouble(bEditText.getText().toString());
                       q.a=b-a;
                       q.b=(b-a)/2+a;
                       q.amount=Double.parseDouble(amountEditText.getText().toString());
                       totalq=Double.parseDouble(amountEditText.getText().toString());
                       qView.setText("Q = "+totalq);                                               
                       myDialog.cancel();
                  }
            });
            myDialog.show();      	
        	break;
        case R.id.addP:
        	Toast.makeText(this, "AddQ", Toast.LENGTH_SHORT).show();        	
        	myDialog = new Dialog(MainActivity.this);
            myDialog.setContentView(R.layout.p_dialog);
            myDialog.setTitle("��������������� ����");
            aEditText=(EditText)myDialog.findViewById(R.id.p_a);    
            amountEditText=(EditText)myDialog.findViewById(R.id.p_amount);             
            temp=(Button)myDialog.findViewById(R.id.p_ok);
            temp.setOnClickListener(new OnClickListener() {
                 @Override
                  public void onClick(View v) {
                        p.a=Double.parseDouble(aEditText.getText().toString());
                        p.amount=Double.parseDouble(amountEditText.getText().toString());
                        totalp=Double.parseDouble(amountEditText.getText().toString());
                        pView.setText("P = "+totalp);                         
                        myDialog.cancel();
                  }
            });
            myDialog.show();    	
        	break;
        case R.id.calc:
        	Toast.makeText(this, "Calc", Toast.LENGTH_SHORT).show();   
        	intent.putExtra("length", length);
        	intent.putExtra("p", p);
        	intent.putExtra("q", q);
        	intent.putExtra("m", m);
            startActivity(intent);        	
        	break;
        
        }
        
        
      }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
      }
      
      // ���������� ����
      @Override
      public boolean onPrepareOptionsMenu(Menu menu) {
        
        return super.onPrepareOptionsMenu(menu);
      }

      // ��������� �������
      @Override
      public boolean onOptionsItemSelected(MenuItem item) {
        
    	  switch (item.getItemId()) {
    	    case R.id.menu_new:
    	    	totalmoment=0;totalp=0;totalq=0;
    	        length=0;
    	        
    	    	myDialog = new Dialog(MainActivity.this);
                myDialog.setContentView(R.layout.length_dialog);
                myDialog.setTitle("������� �����");
                aEditText=(EditText)myDialog.findViewById(R.id.length_a);
                p = new P(0,0);
            	q = new Q(0,0,0);
            	m = new M(0,0);          
                temp=(Button)myDialog.findViewById(R.id.length_ok);
                temp.setOnClickListener(new OnClickListener() {
                     @Override
                      public void onClick(View v) {
                            
                            length = Double.parseDouble(aEditText.getText().toString());
                            lengthView.setText("Length = "+length);
                            qView.setText("Q = "+totalq);  
                            momentView.setText("M = "+totalmoment); 
                            pView.setText("P = "+totalp);  
                            myDialog.cancel();
                      }
                });
                myDialog.show();                	
    	      break;
    	    case R.id.menu_exit:
    	      //exit
    	    	finish();
    	      break;
    	    }
        
        
        return super.onOptionsItemSelected(item);
      }
    
}
